import HomeClient from "./homeClient";

export default function Page() {
  return <HomeClient />;
}
